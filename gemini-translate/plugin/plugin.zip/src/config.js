load('prompts.js');

function execute() {
    var config = {};
    config[translationConfigKey("api_key")] = {
            title: "Gemini API keys",
            subtitle: "Danh sách API key; tự chuyển key khi hết quota",
            default: "",
            mode: "list",
            format: "text"
        };
    config[translationConfigKey("temperature")] = {
            title: "Temperature",
            subtitle: "0.0 - 2.0; giá trị thấp giúp bản dịch ổn định",
            default: "0.2",
            mode: "input",
            format: "number"
        };
    config[translationConfigKey("max_output_tokens")] = {
            title: "Số token đầu ra tối đa",
            default: "16384",
            mode: "input",
            format: "number"
        };
    config[translationConfigKey("thinking_level")] = {
            title: "Mức suy nghĩ (Gemini 3 trở lên): low nhanh, high kỹ nhưng rất chậm, default theo model; Gemma 4 chỉ high là bật",
            default: "low",
            values: ["low", "minimal", "medium", "high", "default"],
            mode: "select"
        };
    config[translationConfigKey("enable_safety_filter")] = {
            title: "Bật bộ lọc an toàn Gemini",
            subtitle: "Mặc định tắt; khi tắt sẽ gửi BLOCK_NONE cho harassment, hate speech, sexually explicit và dangerous content",
            default: "false",
            mode: "toggle"
        };
    config[translationConfigKey("retry_untranslated_chinese")] = {
            title: "Tự sửa phần tiếng Trung còn sót",
            subtitle: "Gom các cụm tiếng Trung còn sót và gọi Gemini đúng 1 lần; nếu lần sửa lỗi thì giữ nguyên bản dịch ban đầu",
            default: "true",
            mode: "toggle"
        };
    config[translationConfigKey("translate_table_of_content")] = {
            title: "Dùng Gemini dịch mục lục",
            subtitle: "Tắt: dùng QT (Trung → Việt), sau đó Baidu; ngôn ngữ Baidu không hỗ trợ sẽ dùng Gemini",
            default: "false",
            mode: "toggle"
        };
    config[translationConfigKey("translate_detail")] = {
            title: "Dùng Gemini dịch chi tiết",
            subtitle: "Tắt: dùng QT (Trung → Việt), sau đó Baidu; ngôn ngữ Baidu không hỗ trợ sẽ dùng Gemini",
            default: "false",
            mode: "toggle"
        };
    config[translationConfigKey("translate_discovery")] = {
            title: "Dùng Gemini dịch khám phá",
            subtitle: "Tắt: dùng QT (Trung → Việt), sau đó Baidu; ngôn ngữ Baidu không hỗ trợ sẽ dùng Gemini",
            default: "false",
            mode: "toggle"
        };
    config[translationConfigKey("use_qt_fallback")] = {
            title: "Ưu tiên QT khi dịch bổ sung",
            subtitle: "Chỉ áp dụng cho nội dung tiếng Trung sang tiếng Việt; nếu tắt hoặc QT không dùng được sẽ chuyển sang Baidu",
            default: "true",
            mode: "toggle"
        };
    config[translationConfigKey("system_prompt")] = {
            title: "Prompt hệ thống dịch thuật",
            subtitle: "Có thể sửa toàn bộ hướng dẫn; giữ các biến {source_language}, {target_language}, {style_prompt}, {source_prompt}, {custom_instruction} và {memory_prompt} nếu muốn dùng dữ liệu tương ứng",
            default: translationDefaultSystemPrompt(),
            mode: "input",
            format: "text"
        };
    config.translation_prompts = {
            title: "Prompt phong cách dịch truyện",
            subtitle: "Dùng chung cho mọi truyện; khi thêm prompt mới hãy để trống bookId, nhập key là ID style và value là nội dung prompt",
            mode: "database"
        };
    config.bypass_prompts = {
            title: "Thư viện prompt lách bộ lọc",
            subtitle: "Danh sách preset; key là ID, value là JSON {\"name\":\"Tên hiển thị\",\"value\":\"Nội dung prefix\"}; có thể thêm mới, sửa hoặc xoá",
            mode: "database"
        };
    config[translationConfigKey("use_translation_memory")] = {
            title: "Sử dụng bộ nhớ dịch",
            subtitle: "Áp dụng tên riêng, địa danh, thuật ngữ và quan hệ đã lưu cho truyện hiện tại; dùng cho mọi cặp ngôn ngữ",
            default: "true",
            mode: "toggle"
        };
    config[translationConfigKey("auto_translation_memory")] = {
            title: "Tự động học bộ nhớ dịch",
            subtitle: "Tự lưu thực thể mới khi dịch chương; chỉ hoạt động khi Sử dụng bộ nhớ dịch đang bật",
            default: "true",
            mode: "toggle"
        };
    config[translationConfigKey("memory_analysis_chapters")] = {
            title: "Số chương phân tích",
            subtitle: "Action sẽ đọc từ chương đang đọc và các chương kế sau, tối đa theo số lượng này",
            default: "5",
            mode: "input",
            format: "number"
        };

    initializeTranslationPrompts();
    initializeBypassPrompts();

    var bookInfo = null;
    try {
        bookInfo = localBook.getInfo();
    } catch (e) {}

    if (bookInfo && bookInfo.id) {
        var bookId = String(bookInfo.id);
        var bookPromptKey = translationConfigKey(translationBookPromptConfigKey(bookId));
        config[bookPromptKey] = {
            title: "Yêu cầu dịch riêng cho truyện",
            subtitle: "Chỉ áp dụng cho truyện hiện tại, ví dụ: giữ cách xưng hô theo phong cách kiếm hiệp",
            default: "",
            mode: "input",
            format: "text"
        };

        // --- Prompt lách: chọn preset hoặc tắt ---
        var bypassValues = ["none"];
        var bypassTitles = ["Tắt (không dùng prompt lách)"];
        try {
            var bypassTotal = localDatabase.count(BYPASS_PROMPT_SCOPE, BYPASS_PROMPT_TABLE);
            var bypassRows = localDatabase.list(BYPASS_PROMPT_SCOPE, BYPASS_PROMPT_TABLE, 0, Math.min(bypassTotal, 100));
            for (var bi = 0; bypassRows && bi < bypassRows.length; bi++) {
                var bKey = String(bypassRows[bi].key || "").trim();
                if (!bKey) continue;
                var bLabel = bKey;
                try {
                    var bData = JSON.parse(String(bypassRows[bi].value || "{}"));
                    if (bData && bData.name) bLabel = String(bData.name);
                } catch (bErr) {}
                bypassValues.push(bKey);
                bypassTitles.push(bLabel);
            }
        } catch (bypassErr) {}

        var bypassSelectKey = translationConfigKey(translationBypassPromptConfigKey(bookId));
        config[bypassSelectKey] = {
            title: "Prompt lách bộ lọc",
            subtitle: "Chọn preset phù hợp thể loại truyện để tránh bị block khi nội dung nhạy cảm; quản lý preset trong 'Thư viện prompt lách bộ lọc'",
            default: "none",
            values: bypassValues,
            titles: bypassTitles,
            mode: "select"
        };

        config.translation_memory = {
            title: "Bộ nhớ dịch theo truyện",
            subtitle: "Tên riêng, địa danh, thuật ngữ và quan hệ do Gemini ghi nhớ; có thể thêm, sửa hoặc xóa thủ công",
            mode: "database"
        };
    }

    return Response.success(config);
}

function initializeTranslationPrompts() {
    try {
        var defaults = translationDefaultPrompts();
        var rows = [];
        var total = localDatabase.count(TRANSLATION_PROMPT_SCOPE, TRANSLATION_PROMPT_TABLE);
        if (total === 0) {
            for (var style in defaults) {
                if (!defaults.hasOwnProperty(style)) continue;
                rows.push({ key: style, value: defaults[style] });
            }
        } else {
            var storedPrompts = {};
            var storedRows = localDatabase.list(
                TRANSLATION_PROMPT_SCOPE,
                TRANSLATION_PROMPT_TABLE,
                0,
                total
            );
            for (var rowIndex = 0; storedRows && rowIndex < storedRows.length; rowIndex++) {
                storedPrompts[String(storedRows[rowIndex].key || "")] = String(storedRows[rowIndex].value || "");
            }
            var definitions = translationDefaultStyleDefinitions();
            for (var index = 0; index < definitions.length; index++) {
                var definition = definitions[index];
                var stored = storedPrompts[definition.id];
                if (stored === translationLegacyPrompt(definition.rule) ||
                    (definition.id === "tu-nhien" && stored === undefined)) {
                    rows.push({ key: definition.id, value: definition.rule });
                }
            }
        }
        if (rows.length > 0) localDatabase.upsertAll(TRANSLATION_PROMPT_SCOPE, TRANSLATION_PROMPT_TABLE, rows);
    } catch (e) {}
}
